ML HW3 README FILE
Produced By: 物理三 潘阜承 B08202036

Since the provided data link was dead, I upload the dataset to my own google drive in order to avoid having to upload the data to the colab workspace everytime. Also, to avoid the loss of model path and prediction file caused by the disconnection of the colab, I changed all the paths in the sample code to my google drive path. Thus, one should change the paths in the colab code to their own desired paths before runinng it in order to prevent error. After changing the paths, one can simply run the code.