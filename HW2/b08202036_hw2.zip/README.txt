ML HW2 README FILE
Produced By: 物理三 潘阜承 B08202036

Since the google drive links were dead, I upload the dataset to my own google drive and change all the paths to my google drive path.
Thus, one should change the paths in my colab code to their own before runinng it.After changing the paths, one can simply run the code.