ML HW3 README FILE
Produced By: 物理三 潘阜承 B08202036

To avoid the loss of model path and prediction file caused by the disconnection of the colab, I changed all the paths in the sample code to my google drive path. Thus, one should change the paths in the colab code to their own desired paths before runinng it in order to prevent error. After changing the paths, one can simply run the code.