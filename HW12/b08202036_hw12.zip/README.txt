ML HW12 README FILE
Produced By: 物理三 潘阜承 B08202036

In this homework, I have added a line in order to save my model to my google drive and load the model later. Thus, one should change the paths for saving and loading model to their own paths when running the code.