ML HW6 README FILE
Produced By: 物理三 潘阜承 B08202036

In this homework, I simply used the command in the github of StyleGan. In my code, I set the paths of saved model and result to be the path of my google drive. Thus, one should change the paths to their desire ones in order to run the code successfully.