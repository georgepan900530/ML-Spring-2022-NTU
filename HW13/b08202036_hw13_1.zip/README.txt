ML HW13 README FILE
Produced By: 物理三 潘阜承 B08202036

In this homework, I have modified the saving and loading path to my google drive. Thus, one should change these path to their own ones before running the code on colab. Also, I have provided the checkpoint of my best model in this zip file. Therefore, one can reproduce my result on Kaggle by simply load the provided checkpoint and run the evaluation part in the code.